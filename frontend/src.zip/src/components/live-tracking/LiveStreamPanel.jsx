import { useEffect, useState } from "react";
import axios from "axios";

const API_BASE = "http://localhost:5000/api/v1";

export default function LiveStreamPanel() {
  const [activeTab, setActiveTab] = useState("live");
  const [loading, setLoading] = useState(false);
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    fetchData(activeTab);
  }, [activeTab]);

  const fetchData = async (tab) => {
    try {
      setLoading(true);
      setVideos([]);

      let url = "";

      if (tab === "live") url = `${API_BASE}/devices`;
      if (tab === "alarms") url = `${API_BASE}/vehicle-itinerary`;
      if (tab === "talk") url = `${API_BASE}/talk`; // future

      const res = await axios.get(url);
      setVideos(res.data || []);
    } catch (err) {
      console.error("API error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow p-3">
      {/* Tabs */}
      <div className="flex gap-6 border-b mb-3 text-sm font-medium">
        <Tab label="Live Stream" active={activeTab === "live"} onClick={() => setActiveTab("live")} />
        <Tab label="Video Alarms" active={activeTab === "alarms"} onClick={() => setActiveTab("alarms")} />
        <Tab label="Talk" active={activeTab === "talk"} onClick={() => setActiveTab("talk")} />
      </div>

      {/* Content */}
      {loading && <Loader />}

      {!loading && videos.length === 0 && (
        <div className="text-center text-gray-400 py-8">No data found</div>
      )}

      {!loading && videos.map((item, index) => (
        <VideoCard key={index} data={item} />
      ))}
    </div>
  );
}
